export { default as otpGenerator } from "./generate_otp";

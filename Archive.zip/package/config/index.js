
export{ default as config} from './config';
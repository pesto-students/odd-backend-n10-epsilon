
export {default  as connectDB} from './db';
